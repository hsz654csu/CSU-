# Modular UAV 6-DOF Simulation in MATLAB/Simulink

This repository contains a modular MATLAB/Simulink simulation project for a quadrotor-style UAV six-degree-of-freedom (6-DOF) closed-loop control system.

The model is organized as an engineering simulation chain:

```text
Guidance -> Navigation Feedback -> Position Controller -> Attitude Controller
         -> Control Allocation -> Propulsion Dynamics -> 6DOF Dynamics
         -> Data Logging
```

The project supports four verification scenarios:

| Mode | Scenario | Target |
|---:|---|---|
| 1 | Hover | Climb to and hold near `(0, 0, 3) m` |
| 2 | Level flight | Track forward motion to about `x = 6 m` while holding `z = 3 m` |
| 3 | Climb | Climb from hover altitude to about `z = 5 m` |
| 4 | Lateral shift | Track lateral motion to about `y = 3 m` while holding `z = 3 m` |

## Features

- Modular Simulink top-level model.
- Quintic polynomial reference trajectory generation.
- Outer-loop position controller with acceleration feedforward.
- Inner-loop attitude controller.
- Quadrotor control allocation.
- First-order motor/propulsion dynamics.
- Rotor-speed-driven rigid-body 6-DOF dynamics.
- Automated simulation, plotting, and metrics export.

## Requirements

- MATLAB R2024a or newer is recommended.
- Simulink.
- Stateflow / MATLAB Function block support.

The project was developed and tested with MATLAB R2024a.

## Quick Start

Open MATLAB, change to the repository root, and run:

```matlab
addpath('scripts')
run_all
```

This will:

1. Rebuild `model/uav_6dof_course.slx`.
2. Run hover, level-flight, climb, and lateral-shift scenarios.
3. Save plots, metrics, and `.mat` result files under `results/`.

You can also run a single scenario:

```matlab
addpath('scripts')
run_hover
run_level_flight
run_climb
run_lateral_shift
```

## Repository Structure

```text
.
├── model/
│   └── uav_6dof_course.slx
├── scripts/
│   ├── create_course_model.m
│   ├── init_uav_params.m
│   ├── run_all.m
│   ├── run_hover.m
│   ├── run_level_flight.m
│   ├── run_climb.m
│   ├── run_lateral_shift.m
│   ├── plot_sim_results.m
│   ├── generate_chapter4_figures.m
│   └── export_interface_summary.m
├── docs/
│   ├── architecture.md
│   ├── results_summary.md
│   └── figures/
├── examples/
│   └── run_project.m
├── .gitignore
├── LICENSE
└── README.md
```

## Main Scripts

| Script | Purpose |
|---|---|
| `create_course_model.m` | Programmatically rebuilds the Simulink model. |
| `init_uav_params.m` | Defines mass, inertia, rotor, drag, and simulation parameters. |
| `run_all.m` | Runs all four scenarios and saves summary metrics. |
| `plot_sim_results.m` | Exports state response, control/rotor plots, 3-D trajectory plots, and metrics text files. |
| `generate_chapter4_figures.m` | Generates additional architecture and validation figures for documentation. |

## Example Results

Typical outputs from the current model are:

| Scenario | Final position / m | Key steady error |
|---|---|---|
| Hover | `[0.0000, 0.0000, 3.0054]` | Steady altitude RMS error about `0.0055 m` |
| Level flight | `[5.9501, 0.0000, 3.0054]` | Steady x RMS error about `0.0684 m` |
| Climb | `[0.0000, 0.0000, 5.0061]` | Steady altitude RMS error about `0.0077 m` |
| Lateral shift | `[0.0000, 2.9827, 3.0054]` | Steady y RMS error about `0.0345 m` |

These values may change slightly if controller parameters or MATLAB/Simulink solver settings are modified.

## Notes

- The model is intended for course-level UAV control simulation and architecture demonstration.
- It is not a high-fidelity aerodynamic model.
- The current 6-DOF subsystem is rotor-speed driven and includes simplified rigid-body dynamics, gravity, and linear damping.
- Wind, sensor noise, actuator faults, and estimator dynamics are not included by default.

## License

This project is released under the MIT License. See [LICENSE](LICENSE).
